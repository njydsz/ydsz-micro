const t="Demos",e={title:t};export{e as default,t as title};
