import{d as r,x as t,I as a}from"./vendor-s8DptrvB.js";function s(n){return r({name:`Icon-${n}`,setup(e,{attrs:o}){return()=>t(a,{icon:n,...e,...o})}})}export{s as c};
