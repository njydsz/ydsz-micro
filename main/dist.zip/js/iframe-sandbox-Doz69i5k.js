const P="width:100%;height:100%;border:0;display:block;margin:0;padding:0;",f="__MICRO_KERNEL_BRIDGE__";function G(e){return typeof e=="object"&&e!==null&&e[f]===!0}const b={timeout:3e4,retry:{enabled:!1,maxRetries:2,baseDelay:1e3,isIdempotent:e=>/^(get|query|fetch|read|select|find)/i.test(e)}};function x(e){const h=e.document,c=window.location.origin,p=c&&c!=="null"?c:"*",m=h.createElement("script");m.textContent=`
    (function() {
      // 当前 globalState 快照（由主应用同步过来）
      window.__MICRO_GLOBAL_STATE__ = {};

      // v4.3.0: 子 → 主消息目标 origin（主 realm 注入，精确到宿主 origin）
      var __TARGET_ORIGIN__ = ${JSON.stringify(p)};

      // 子应用调用此方法回写状态到主应用
      window.__MICRO_SET_GLOBAL_STATE__ = function(patch) {
        window.parent.postMessage({
          ${f}: true,
          type: 'state-set',
          payload: patch
        }, __TARGET_ORIGIN__);
      };

      // ===== RPC 协议 v3.6.1 增强 =====
      // 子应用注册给主应用调用的 API 处理器
      window.__MICRO_REGISTERED_API__ = {};
      window.__MICRO_REGISTER_API__ = function(handlers) {
        window.__MICRO_REGISTERED_API__ = handlers || {};
      };

      // 子应用 → 主应用 RPC 调用（返回 Promise）
      var __rpcSeq__ = 0;
      var __pendingCalls__ = {};
      window.__MICRO_CALL_MAIN__ = function(method, args) {
        return new Promise(function(resolve, reject) {
          var callId = 'm' + (++__rpcSeq__);
          __pendingCalls__[callId] = { resolve: resolve, reject: reject };
          window.parent.postMessage({
            ${f}: true,
            type: 'rpc-call',
            payload: { method: method, args: args || [], callId: callId }
          }, __TARGET_ORIGIN__);
        });
      };

      // 主 → 子 RPC 调用处理：执行后回传结果
      window.__MICRO_EXECUTE_RPC__ = function(payload) {
        var handler = window.__MICRO_REGISTERED_API__[payload.method];
        var result;
        var ok = true;
        var error;
        if (typeof handler !== 'function') {
          ok = false;
          error = 'RPC method not found: ' + payload.method;
        } else {
          try {
            result = handler.apply(null, payload.args || []);
          } catch (e) {
            ok = false;
            error = String(e && e.message || e);
          }
        }
        // 支持 Promise 返回值
        if (ok && result && typeof result.then === 'function') {
          result.then(function(value) {
            window.parent.postMessage({
              ${f}: true,
              type: 'rpc-result',
              payload: { callId: payload.callId, ok: true, result: value }
            }, __TARGET_ORIGIN__);
          }).catch(function(err) {
            window.parent.postMessage({
              ${f}: true,
              type: 'rpc-result',
              payload: { callId: payload.callId, ok: false, error: String(err && err.message || err) }
            }, __TARGET_ORIGIN__);
          });
          return;
        }
        window.parent.postMessage({
          ${f}: true,
          type: 'rpc-result',
          payload: { callId: payload.callId, ok: ok, result: result, error: error }
        }, __TARGET_ORIGIN__);
      };

      // 监听主应用发来的消息（v4.3.0: 校验消息来源为父窗口）
      window.addEventListener('message', function(event) {
        if (event.source !== window.parent) return;
        var data = event.data;
        if (!data || data.${f} !== true) return;
        if (data.type === 'state-sync') {
          window.__MICRO_GLOBAL_STATE__ = data.payload || {};
        } else if (data.type === 'rpc-call') {
          window.__MICRO_EXECUTE_RPC__(data.payload);
        } else if (data.type === 'rpc-result') {
          var pending = __pendingCalls__[data.payload.callId];
          if (pending) {
            delete __pendingCalls__[data.payload.callId];
            if (data.payload.ok) {
              pending.resolve(data.payload.result);
            } else {
              pending.reject(new Error(data.payload.error || 'RPC call failed'));
            }
          }
        }
      });
    })();
  `,h.head.append(m),m.remove()}function $(e,h,c={}){const p=window.location.origin,m=c.targetOrigin&&c.targetOrigin!=="null"?c.targetOrigin:p&&p!=="null"?p:"*",n=c.expectedOrigins?.length?new Set(c.expectedOrigins):null,v={},s=new Map;let l=0;const _=new Set,O=r=>{if(r.source!==e||n&&!n.has(r.origin))return;const a=r.data;if(G(a)){if(a.type==="state-set"){for(const t of _)try{t(a.payload)}catch{}return}if(a.type==="rpc-result"){const t=a.payload,I=s.get(t.callId);I&&(s.delete(t.callId),t.ok?I.resolve(t.result):I.reject(new Error(t.error||"RPC call failed")));return}if(a.type==="rpc-call"){const t=a.payload,I=v[t.method],g=(o,i,E)=>{const M={[f]:!0,type:"rpc-result",payload:{callId:t.callId,ok:o,result:i,error:E}};e.postMessage(M,m)};if(typeof I!="function"){g(!1,void 0,`RPC method not found: ${t.method}`);return}try{const o=I(...t.args);o&&typeof o.then=="function"?Promise.resolve(o).then(i=>g(!0,i),i=>g(!1,void 0,String(i?.message||i))):g(!0,o)}catch(o){g(!1,void 0,String(o instanceof Error?o.message:o))}}}},y=r=>{if(!e)return;const a={[f]:!0,type:"state-sync",payload:r};e.postMessage(a,m)},R=r=>(_.add(r),()=>{_.delete(r)});async function w(r,a=[]){if(!e)throw new Error("[IframeRpc] ContentWindow is not available");const t=h.retry,I=t.isIdempotent?.(r)??!1,g=t.enabled&&I?1+(t.maxRetries??2):1;let o;for(let i=0;i<g;i++){if(i>0){const d=(t.baseDelay??1e3)*2**(i-1);if(await new Promise(A=>setTimeout(A,d)),!e)throw new Error("[IframeRpc] ContentWindow closed during retry")}const E=`p${++l}`,M=new Promise((d,A)=>{s.set(E,{resolve:d,reject:A})}),T={[f]:!0,type:"rpc-call",payload:{method:r,args:a,callId:E}};e.postMessage(T,m);const S=setTimeout(()=>{const d=s.get(E);d&&(s.delete(E),d.reject(new Error(`[IframeRpc] RPC timeout: ${r} (attempt ${i+1}/${g})`)))},h.timeout);try{const d=await M;return clearTimeout(S),d}catch(d){if(o=d instanceof Error?d:new Error(String(d)),i===g-1)throw o}}throw o??new Error(`[IframeRpc] RPC failed: ${r}`)}function u(r){for(const[a,t]of Object.entries(r))v[a]=t;return()=>{for(const a of Object.keys(r))delete v[a]}}function C(r){_.clear();for(const{reject:a}of s.values())a(new Error(`[IframeSandbox:${r}] Sandbox closed`));s.clear()}return{onMessage:O,postToChild:y,onChildMessage:R,callRpc:w,registerMainApi:u,cleanupRpc:C}}function D(e,h,c,p){const m={timeout:p?.timeout??b.timeout,retry:{enabled:p?.retry?.enabled??b.retry.enabled,maxRetries:p?.retry?.maxRetries??b.retry.maxRetries,baseDelay:p?.retry?.baseDelay??b.retry.baseDelay,isIdempotent:p?.retry?.isIdempotent??b.retry.isIdempotent}},n=document.createElement("iframe");n.setAttribute("aria-label",`sub-app-${e}`),n.dataset.microSandbox="iframe",n.setAttribute("style",P);const v=c&&!1;n.setAttribute("src","about:blank"),n.dataset.iframeMode="esm-hosted",h.append(n);const s=n.contentWindow,l=v?null:n.contentDocument;if(!s)throw n.remove(),new Error(`[IframeSandbox:${e}] Failed to access iframe contentWindow`);let _=null;{if(!l)throw n.remove(),new Error(`[IframeSandbox:${e}] Failed to access iframe contentDocument`);l.open(),l.write('<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body></body></html>'),l.close();try{document.querySelectorAll("style[data-shared-style], link[data-shared-style]").forEach(C=>{l.head.append(C.cloneNode(!0))})}catch{}_=l.createElement("div"),_.setAttribute("id","subapp-container"),_.dataset.microApp=e,l.body.append(_),x(s)}const O=window.location.origin,y=$(s,m,{targetOrigin:O,expectedOrigins:[O]});window.addEventListener("message",y.onMessage);let R=!1,w=!1;return{contentWindow:s,contentDocument:l,container:_,activate(){R||w||(R=!0)},deactivate(){!R||w||(R=!1)},cleanup(){if(!w){w=!0,R=!1,window.removeEventListener("message",y.onMessage),y.cleanupRpc(e);try{l?.write(""),l?.close()}catch{}n.remove()}},postToChild(u){w||y.postToChild(u)},onChildMessage(u){return y.onChildMessage(u)},callRpc(u,C=[]){if(w||!s)throw new Error(`[IframeSandbox:${e}] Sandbox is closed`);return y.callRpc(u,C)},registerMainApi(u){return y.registerMainApi(u)}}}export{D as createIframeSandbox};
