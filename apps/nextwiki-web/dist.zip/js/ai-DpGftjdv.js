import{N as t}from"../jse/index-index-PNdc5AKk.js";function r(e){return t.post("/nextwiki/ai/summary",e)}function i(){return t.get("/nextwiki/ai/status")}export{r as a,i as g};
