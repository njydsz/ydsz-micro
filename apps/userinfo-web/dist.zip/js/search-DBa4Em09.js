import{O as c}from"../jse/index-index-B9bKwBL6.js";const r=c("search",[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]]);export{r as S};
