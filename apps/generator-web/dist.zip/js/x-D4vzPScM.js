import{W as e}from"../jse/index-index-Cdu1Tuio.js";const o=e("x",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]);export{o as X};
